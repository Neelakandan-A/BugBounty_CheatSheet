## Bug Bounty Platforms

**Open For Signup**

- [HackerOne](https://www.hackerone.com/)
- [Bugcrowd](https://www.bugcrowd.com/)
- [BountyFactory](https://bountyfactory.io/)
- [Intigriti](https://intigriti.be/)
- [Bugbountyjp](https://bugbounty.jp/)
- [Safehats](https://safehats.com/)
- [BugbountyHQ](https://www.bugbountyhq.com/)
- [Hackerhive](https://hackerhive.io/)
- [Hackenproof](https://hackenproof.com/)


**Invite based Platforms**

- [Synack](https://www.synack.com/red-team/)
- [Cobalt](https://cobalt.io/)
- [Zerocopter](https://zerocopter.com/)
- [Yogosha](https://www.yogosha.com/)
- [Bugbountyzone](https://bugbountyzone.com/)
- [Antihack.me](http://www.antihack.me/)
- [Vulnscope](https://www.vulnscope.com/)
