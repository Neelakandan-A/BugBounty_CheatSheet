## Practice Platforms

- [Pentesterlab](https://pentesterlab.com/)
- [XSS Game](https://xss-game.appspot.com/)
- [Hack This Site](https://www.hackthissite.org)
- [Root-Me](https://www.root-me.org)
- [HackTheBox](https://www.hackthebox.eu)
- [Hack Me](https://hack.me) 
- [CTF 365](https://ctf365.com)
- [Google Gruyere](https://google-gruyere.appspot.com/)
- [OWASP Juice Shop](http://juice-shop.herokuapp.com/)
- [Hack Yourself First](http://hackyourselffirst.troyhunt.com/)
- [bWAPP](http://www.itsecgames.com/)
-[OWASP Mutillidae] (https://www.owasp.org/index.php/OWASP_Mutillidae_2_Project)
